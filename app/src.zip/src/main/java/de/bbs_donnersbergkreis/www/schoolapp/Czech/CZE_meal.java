package de.bbs_donnersbergkreis.www.schoolapp.Czech;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.bbs_donnersbergkreis.www.schoolapp.R;

public class CZE_meal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cze_meal);
    }
}
