package de.bbs_donnersbergkreis.www.schoolapp.Germany;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.bbs_donnersbergkreis.www.schoolapp.R;

public class Germany_Discussion_blog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_germany__discussion_blog);
    }
}
