package de.bbs_donnersbergkreis.www.schoolapp.Poland;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.bbs_donnersbergkreis.www.schoolapp.R;

public class Poland extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poland);
    }
}
